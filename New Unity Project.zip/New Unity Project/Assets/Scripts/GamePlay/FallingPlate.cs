﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FallingPlate : IntEventInvoker
{

    [SerializeField]
    GameObject preFabExplosion;

    int health = 150;
    // Start is called before the first frame update
    void Start()
    {
        unityEvents.Add(EventName.HealthChangedEvent, new HealthChangedEvent());
        EventManager.AddInvoker(EventName.HealthChangedEvent, this);

        unityEvents.Add(EventName.PointsAddedEvent, new PointsAddedEvent());
        EventManager.AddInvoker(EventName.PointsAddedEvent, this);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.CompareTag("Player"))
        {
            Instantiate(preFabExplosion, other.gameObject.transform.position, Quaternion.identity);
            //Destroy(other.gameObject);
            Instantiate(preFabExplosion, transform.position, Quaternion.identity);
            Destroy(gameObject);
        }
        if (other.gameObject.CompareTag("Shot"))
        {
            Instantiate(preFabExplosion, other.gameObject.transform.position, Quaternion.identity);
            TakeDamage(25);
        }

    }

    private void OnBecameInvisible()
    {
        Destroy(gameObject);
    }

    void TakeDamage(int damage)
    {
        health = Mathf.Max(0, health - damage);
        unityEvents[EventName.HealthChangedEvent].Invoke(health);

        if (health == 0)
        {
            unityEvents[EventName.PointsAddedEvent].Invoke(20);
            Destroy(gameObject);
        }
    }
}
