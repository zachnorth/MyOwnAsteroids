﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BiggerEnemy : IntEventInvoker
{
    [SerializeField]
    GameObject preFabShot;

    [SerializeField]
    GameObject preFabEnemy;

    GameObject player;

    GameObject newShot;

    Timer shotCooldown;

    int health = 150;

    // Start is called before the first frame update
    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player");

        shotCooldown = gameObject.AddComponent<Timer>();
        shotCooldown.Duration = 2.0f;
        shotCooldown.Run();

        unityEvents.Add(EventName.HealthChangedEvent, new HealthChangedEvent());
        EventManager.AddInvoker(EventName.HealthChangedEvent, this);

        unityEvents.Add(EventName.PointsAddedEvent, new PointsAddedEvent());
        EventManager.AddInvoker(EventName.PointsAddedEvent, this);
    }

    // Update is called once per frame
    void Update()
    {
        transform.position = Vector3.MoveTowards(transform.position, player.transform.position, .02f);

        if (shotCooldown.Finished)
        {
            newShot = Instantiate(preFabShot, gameObject.transform.position, Quaternion.identity);
            newShot.GetComponent<Rigidbody2D>().AddForce(
                new Vector2(player.transform.position.x - gameObject.transform.position.x,
                player.transform.position.y - gameObject.transform.position.y).normalized * 10,
                ForceMode2D.Impulse);
            shotCooldown.Duration = 2.0f;
            shotCooldown.Run();
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Shot"))
        {
            TakeDamage(25);
        }
    }

    public void Split(GameObject location)
    {
        GameObject topLeft = Instantiate(preFabEnemy, location.transform.position, Quaternion.identity);
        topLeft.GetComponent<Rigidbody2D>().AddForce(new Vector2(0, Screen.height).normalized * 10, ForceMode2D.Impulse);

        GameObject topRight = Instantiate(preFabEnemy, location.transform.position + new Vector3(1, 1, 1), Quaternion.identity);
        topRight.GetComponent<Rigidbody2D>().AddForce(new Vector2(Screen.width, Screen.height).normalized,
            ForceMode2D.Impulse);

        GameObject bottomLeft = Instantiate(preFabEnemy, location.transform.position - new Vector3(1, 1, 1), Quaternion.identity);
        bottomLeft.GetComponent<Rigidbody2D>().AddForce(new Vector2(0, 0).normalized, ForceMode2D.Impulse);

        GameObject bottomRight = Instantiate(preFabEnemy, -location.transform.position, Quaternion.identity);
        bottomRight.GetComponent<Rigidbody2D>().AddForce(new Vector2(Screen.width, 0).normalized, ForceMode2D.Impulse);
    }


    void TakeDamage(int damage)
    {
        health = Mathf.Max(0, health - damage);
        unityEvents[EventName.HealthChangedEvent].Invoke(health);

        if (health <= 0)
        {
            Debug.Log("Ouch!");
            unityEvents[EventName.PointsAddedEvent].Invoke(100);
            Split(gameObject);
            Destroy(gameObject);
        }
    }

    private void OnBecameInvisible()
    {
        Destroy(gameObject);
    }
}
