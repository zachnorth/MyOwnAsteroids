﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player1 : IntEventInvoker
{
    [SerializeField]
    GameObject preFabShot;

    [SerializeField]
    GameObject preFabExplosion;

    float colliderHalfWidth;
    float colliderHalfHeight;

    float screenLeft;
    float screenRight;
    float screenTop;
    float screenBottom;

    float Player1MoveUnitsPerSecond = 10;
    const float ShotPositionOffset = 0.2f;

    Timer timer;

    int health = 100;

    GameObject newShot;

    float shotImpulseForce = 10;

    // Start is called before the first frame update
    void Start()
    {

        Debug.Log(health);
        //save screen edges in world coordinates
        float screenZ = -Camera.main.transform.position.z;
        Vector3 lowerLeftCornerScreen = new Vector3(0, 0, screenZ);
        Vector3 upperRightCornerScreen = new Vector3(Screen.width, Screen.height, screenZ);
        Vector3 lowerLeftCornerWorld = Camera.main.ScreenToWorldPoint(lowerLeftCornerScreen);
        Vector3 upperRightCornerWorld = Camera.main.ScreenToWorldPoint(upperRightCornerScreen);

        screenLeft = lowerLeftCornerWorld.x;
        screenRight = upperRightCornerWorld.x;
        screenTop = upperRightCornerWorld.y;
        screenBottom = lowerLeftCornerWorld.y;

        //save collider dimension values
        BoxCollider2D player1Collider = GetComponent<BoxCollider2D>();
        Vector3 diff = player1Collider.bounds.max - player1Collider.bounds.min;
        colliderHalfWidth = diff.x / 2;
        colliderHalfHeight = diff.y / 2;
        
        timer = gameObject.AddComponent<Timer>();

        unityEvents.Add(EventName.HealthChangedEvent, new HealthChangedEvent());
        EventManager.AddInvoker(EventName.HealthChangedEvent, this);

    }

    // Update is called once per frame
    void Update()
    {
        Vector3 position = transform.position;

        //get new horizontal position
        float horizontalInput = Input.GetAxis("Horizontal");
        if(horizontalInput < 0)
        {
            position.x += horizontalInput * Player1MoveUnitsPerSecond * Time.deltaTime;
        }
        else if (horizontalInput > 0)
        {
            position.x += horizontalInput * Player1MoveUnitsPerSecond * Time.deltaTime;
        }

        float verticalInput = Input.GetAxis("Vertical");
        if(verticalInput < 0 || verticalInput > 0)
        {
            position.y += verticalInput * Player1MoveUnitsPerSecond * Time.deltaTime;
        }

        transform.position = position;
        ClampInScreen();

        if (Input.GetAxisRaw("Shoot") != 0 && !timer.Running)   //Input.GetAxisRaw("Fire1") != 0
        {
            timer.Duration = 0.2f;
            timer.Run();
            Vector3 shotPos = transform.position;
            shotPos.y += ShotPositionOffset;
            newShot = Instantiate(preFabShot, shotPos, Quaternion.identity);
            newShot.GetComponent<Rigidbody2D>().AddForce(new Vector2(0, shotImpulseForce), ForceMode2D.Impulse);
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if(other.CompareTag("Plate"))
        {
            Instantiate(preFabExplosion, other.gameObject.transform.position, Quaternion.identity);
            Destroy(other.gameObject);
            TakeDamage(10);
        }
        else if(other.CompareTag("Enemy"))
        {
            Instantiate(preFabExplosion, other.gameObject.transform.position, Quaternion.identity);
            TakeDamage(5);
        }
        
        else if(other.CompareTag("EnemyShot"))
        {
            Instantiate(preFabExplosion, other.gameObject.transform.position, Quaternion.identity);
            TakeDamage(5);
        }
    }


    void ClampInScreen()
    {
        // check boundaries and shift as necessary
        Vector3 position = transform.position;
        if (position.x - colliderHalfWidth < screenLeft)
        {
            position.x = screenLeft + colliderHalfWidth;
        }
        if (position.x + colliderHalfWidth > screenRight)
        {
            position.x = screenRight - colliderHalfWidth;
        }
        if (position.y + colliderHalfHeight > screenTop)
        {
            position.y = screenTop - colliderHalfHeight;
        }
        if (position.y - colliderHalfHeight < screenBottom)
        {
            position.y = screenBottom + colliderHalfHeight;
        }
        transform.position = position;
    }

    void TakeDamage(int damage)
    {
        health = Mathf.Max(0, health - damage);
        unityEvents[EventName.HealthChangedEvent].Invoke(health);
        Debug.Log(health);

        if (health <= 0)
        {
            Instantiate(preFabExplosion, gameObject.transform.position, Quaternion.identity);
            Destroy(gameObject);
            Debug.Log("Player died!");
        }
    }
}
