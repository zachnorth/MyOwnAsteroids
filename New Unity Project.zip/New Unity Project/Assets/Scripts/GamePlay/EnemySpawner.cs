﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySpawner : MonoBehaviour
{
    [SerializeField]
    GameObject preFabEnemy;

    [SerializeField]
    GameObject preFabPlate;

    [SerializeField]
    GameObject preFabAggressiveEnemy;

    [SerializeField]
    GameObject preFabBiggerEnemy;

    Timer spawnTimerEnemy;
    Timer spawnTimerPlate;
    Timer spawnTimerAggressiveEnemy;
    Timer spawnTimerBiggerEnemy;

    Vector3 locationPlate = new Vector3();
    Vector3 location = new Vector3();
    Vector3 locationAggressiveEnemy = new Vector3();
    Vector3 locationBiggerEnemy = new Vector3();

    int minSpawnX;
    int maxSpawnX;
    int minSpawnY;
    int maxSpawnY;

    const int MaxSpawnTries = 20;
    float enemyColliderHalfWidth;
    float enemyColliderHalfHeight;
    Vector2 min = new Vector2();
    Vector2 max = new Vector2();

    const int BaseWidth = 800;
    const int BaseHeight = 600;
    const int BaseBorderSize = 100;

    float MinSpawnDelay = 0.1f;
    float MaxSpawnDelay = 1.0f;

    float MinSpawnDelayPlate = 2.0f;
    float MaxSpawnDelayPlate = 6.0f;

    float MinSpawnDelayAggressiveEnemy = 5.0f;
    float MaxSpawnDelayAggressiveEnemy = 8.0f;

    float MinSpawnDelayBiggerEnemy = 10.0f;
    float MaxSpawnDelayBiggerEnemy = 20.0f;


    // Start is called before the first frame update
    void Start()
    {
        float widthRation = (float)Screen.width / BaseWidth;
        float heightRation = (float)Screen.height / BaseHeight;
        float resolutionRatio = (widthRation + heightRation) / 2;
        int spawnBorderSize = (int)(BaseBorderSize * resolutionRatio);

        minSpawnX = spawnBorderSize;
        maxSpawnX = Screen.width - spawnBorderSize;
        minSpawnY = spawnBorderSize;
        maxSpawnY = Screen.height - spawnBorderSize;

        GameObject tempEnemy = Instantiate(preFabEnemy) as GameObject;
        BoxCollider2D collider = tempEnemy.GetComponent<BoxCollider2D>();
        enemyColliderHalfWidth = collider.size.x / 2;
        enemyColliderHalfHeight = collider.size.y / 2;
        Destroy(tempEnemy);

        spawnTimerEnemy = gameObject.AddComponent<Timer>();
        spawnTimerEnemy.Duration = Random.Range(MinSpawnDelay, MaxSpawnDelay);
        spawnTimerEnemy.Run();

        spawnTimerPlate = gameObject.AddComponent<Timer>();
        spawnTimerPlate.Duration = Random.Range(MinSpawnDelayPlate, MaxSpawnDelayPlate);
        spawnTimerPlate.Run();

        spawnTimerAggressiveEnemy = gameObject.AddComponent<Timer>();
        spawnTimerAggressiveEnemy.Duration = Random.Range(MinSpawnDelayAggressiveEnemy, MaxSpawnDelayAggressiveEnemy);
        spawnTimerAggressiveEnemy.Run();

        spawnTimerBiggerEnemy = gameObject.AddComponent<Timer>();
        spawnTimerBiggerEnemy.Duration = Random.Range(MinSpawnDelayBiggerEnemy, MaxSpawnDelayBiggerEnemy);
        spawnTimerBiggerEnemy.Run();
    }

    // Update is called once per frame
    void Update()
    {
        if(spawnTimerEnemy.Finished)
        {
            SpawnEnemy();
        }

        if(spawnTimerPlate.Finished)
        {
            SpawnPlate();
        }

        if(spawnTimerAggressiveEnemy.Finished)
        {
            SpawnAggressiveEnemy();
        }

        if(spawnTimerBiggerEnemy.Finished)
        {
            SpawnBiggerEnemy();
        }
    }


    void SpawnBiggerEnemy()
    {
        location.x = Random.Range(minSpawnX, maxSpawnX);
        location.y = Random.Range(minSpawnY, maxSpawnY);
        location.z = -Camera.main.transform.position.z;

        Vector3 worldLocation = Camera.main.ScreenToWorldPoint(location);
        SetMinAndMax(worldLocation);

        int spawnTries = 1;
        while (Physics2D.OverlapArea(min, max) != null && spawnTries < MaxSpawnTries)
        {
            location.x = Random.Range(minSpawnX, maxSpawnX);
            location.y = Random.Range(minSpawnY, maxSpawnY);
            worldLocation = Camera.main.ScreenToWorldPoint(location);
            SetMinAndMax(worldLocation);

            spawnTries++;
        }

        if (Physics2D.OverlapArea(min, max) == null)
        {
            GameObject biggerEnemy = Instantiate(preFabBiggerEnemy) as GameObject;
            biggerEnemy.transform.position = worldLocation;
            spawnTimerBiggerEnemy.Duration = Random.Range(MinSpawnDelayBiggerEnemy, MaxSpawnDelayBiggerEnemy);
            spawnTimerBiggerEnemy.Run();
        }
    }
    void SpawnAggressiveEnemy()
    {
        location.x = Random.Range(minSpawnX, maxSpawnX);
        location.y = Random.Range(minSpawnY, maxSpawnY);
        location.z = -Camera.main.transform.position.z;
        
        Vector3 worldLocation = Camera.main.ScreenToWorldPoint(location);
        SetMinAndMax(worldLocation);

        int spawnTries = 1;
        while (Physics2D.OverlapArea(min, max) != null && spawnTries < MaxSpawnTries)
        {
            location.x = Random.Range(minSpawnX, maxSpawnX);
            location.y = Random.Range(minSpawnY, maxSpawnY);
            worldLocation = Camera.main.ScreenToWorldPoint(location);
            SetMinAndMax(worldLocation);

            spawnTries++;
        }

        if (Physics2D.OverlapArea(min, max) == null)
        {
            GameObject aggressiveEnemy = Instantiate(preFabAggressiveEnemy) as GameObject;
            aggressiveEnemy.transform.position = worldLocation;
            spawnTimerAggressiveEnemy.Duration = Random.Range(MinSpawnDelayAggressiveEnemy, MaxSpawnDelayAggressiveEnemy);
            spawnTimerAggressiveEnemy.Run();
        }
    }

    void SpawnEnemy()
    {
        int randX = Random.Range(1, 4);
        //int randY = Random.Range(1, 4);

        switch(randX)
        {
            case 1:
                location.x = Random.Range(minSpawnX, maxSpawnX);
                location.y = Screen.height;
                location.z = -Camera.main.transform.position.z;
                break;
            case 2:
                location.x = Random.Range(minSpawnX, maxSpawnX);
                location.y = -Screen.height;
                location.z = -Camera.main.transform.position.z;
                break;
            case 3:
                location.x = Screen.width;
                location.y = Random.Range(minSpawnY, maxSpawnY);
                location.z = -Camera.main.transform.position.z;
                break;
            default:
                location.x = -Screen.width;
                location.y = Random.Range(minSpawnY, maxSpawnY);
                location.z = -Camera.main.transform.position.z;
                break;
        }
        
        Vector3 worldLocation = Camera.main.ScreenToWorldPoint(location);
        SetMinAndMax(worldLocation);

        int spawnTries = 1;
        while (Physics2D.OverlapArea(min, max) != null && spawnTries < MaxSpawnTries)
        {
            location.x = Random.Range(minSpawnX, maxSpawnX);
            location.y = Random.Range(minSpawnY, maxSpawnY);
            worldLocation = Camera.main.ScreenToWorldPoint(location);
            SetMinAndMax(worldLocation);

            spawnTries++;
        }

        if(Physics2D.OverlapArea(min, max) == null)
        {
            GameObject enemy = Instantiate(preFabEnemy) as GameObject;
            enemy.transform.position = worldLocation;
            spawnTimerEnemy.Duration = Random.Range(MinSpawnDelay, MaxSpawnDelay);
            spawnTimerEnemy.Run();
        }
    }
    void SpawnPlate()
    {
        location.x = Random.Range(minSpawnX, maxSpawnX);
        location.y = Screen.height;
        location.z = -Camera.main.transform.position.z;
        Vector3 worldLocation = Camera.main.ScreenToWorldPoint(location);

        GameObject plate = Instantiate(preFabPlate) as GameObject;
        plate.transform.position = worldLocation;
        spawnTimerPlate.Duration = Random.Range(MinSpawnDelayPlate, MaxSpawnDelayPlate);
        spawnTimerPlate.Run();
    }


    void SetMinAndMax(Vector3 location)
    {
        min.x = location.x - enemyColliderHalfWidth;
        min.y = location.y - enemyColliderHalfHeight;
        max.x = location.x + enemyColliderHalfWidth;
        max.y = location.y + enemyColliderHalfHeight;
    }
}
