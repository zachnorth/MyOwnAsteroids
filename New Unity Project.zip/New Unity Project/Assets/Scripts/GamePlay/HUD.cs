﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HUD : MonoBehaviour
{
    [SerializeField]
    Text scoreText;
    int score = 0;

    [SerializeField]
    Slider healthBar;


    // Start is called before the first frame update
    void Start()
    {
        EventManager.AddListener(EventName.PointsAddedEvent, HandlePointsAddedEvent);

        scoreText.text = "Score: " + score;

        EventManager.AddListener(EventName.HealthChangedEvent, HandleHealthChangedEvent);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    #region Private Methods

    private void HandlePointsAddedEvent(int points)
    {
        score += points;
        scoreText.text = "Score: " + score;
    }

    private void HandleHealthChangedEvent(int value)
    {
        healthBar.value = value;
    }

    #endregion
}
