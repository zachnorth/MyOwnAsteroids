﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shot : IntEventInvoker
{
    [SerializeField]
    GameObject preFabExplosion;
    
    // Start is called before the first frame update
    void Start()
    {
        unityEvents.Add(EventName.PointsAddedEvent, new PointsAddedEvent());
        EventManager.AddInvoker(EventName.PointsAddedEvent, this);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.CompareTag("Enemy"))
        {
            unityEvents[EventName.PointsAddedEvent].Invoke(10);
            Instantiate(preFabExplosion, other.gameObject.transform.position, Quaternion.identity);
            Destroy(other.gameObject);
            Instantiate(preFabExplosion, transform.position, Quaternion.identity);
            Destroy(gameObject);
        }
    }

    void OnBecameInvisible()
    {
        EventManager.RemoveInvoker(EventName.PointsAddedEvent, this);
        Destroy(gameObject);
    }
}
